# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


# def print_hi(name):
# Use a breakpoint in the code line below to debug your script.
# print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
# if __name__ == '__main__':
# print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/

import random
import arcade

# --- Constants ---

SPRITE_SCALING_PLAYER = .5
SPRITE_SCALING_FLY = .25
SPRITE_SCALING_BEE = .3
FLY_COUNTER = 1
MOVEMENT_SPEED = 5

SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500
SCREEN_TITLE = "Fly Muncher"

GAME_INTRO = 1
GAME_RUNNING = 2
GAME_OVER = 3

class MyGame(arcade.Window):
   # Window Class

    def __init__(self):
       # Call the parent class initializer
       super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)

       # Variables that will hold sprite lists
       self.player_list = None
       self.fly_list = []
       self.bee_list = []

       # Set up the player info
       self.player_sprite = None
       self.score = 0

        # Set up sounds
       self.endnoise = arcade.load_sound(":resources:sounds/phaseJump1.wav")
       self.eatnoise = arcade.load_sound(":resources:sounds/secret4.wav")



       # Don't show the mouse cursor
       self.set_mouse_visible(False)

       arcade.set_background_color(arcade.color.GRAY_BLUE)

    def setup(self):
       # Set up the game and initializer

       # Sprite lists
       self.player_list = arcade.SpriteList()
       self.fly = arcade.SpriteList()
       self.bee = arcade.SpriteList()
       self.scene = arcade.Scene()
       # Score
       self.score = 0

       # Start w/ intro screen
       self.current_state = GAME_INTRO

       # Set up the player frog
       img = ":resources:images/enemies/frog.png"
       self.player_sprite = arcade.Sprite(img, SPRITE_SCALING_PLAYER)
       self.player_sprite.center_x = random.randrange(SCREEN_WIDTH)
       self.player_sprite.center_y = random.randrange(SCREEN_HEIGHT)
       self.player_list.append(self.player_sprite)


       # Create the flies
       for i in range(1):
           fly = arcade.Sprite(":resources:images/enemies/fly.png",SPRITE_SCALING_FLY)
           fly.center_x = random.randrange(SCREEN_WIDTH)
           fly.center_y = random.randrange(SCREEN_HEIGHT)

           # Add the fly to a scene
           self.scene.add_sprite("Flies", fly)

        # Create the bee
       for i in range(1):
           bee = arcade.Sprite(":resources:images/enemies/bee.png", SPRITE_SCALING_BEE)
           bee.center_x = random.randrange(SCREEN_WIDTH)
           bee.center_y = random.randrange(SCREEN_HEIGHT)


           # Add the bee to a scene
           self.scene.add_sprite("Bees", bee)


    def on_draw(self):
       # Draw the scene
       arcade.start_render()

        # Text on intro screen and instructions
       if self.current_state == GAME_INTRO:
           arcade.draw_text("Welcome to Fly Muncher!", SCREEN_WIDTH // 16, SCREEN_HEIGHT // 2 + 30, arcade.color.WHITE,
                            13)
           arcade.draw_text("Use the arrow keys to move the frog and consume flies.", SCREEN_WIDTH // 16, SCREEN_HEIGHT // 2,
                            arcade.color.WHITE,
                            13)
           arcade.draw_text("Careful for the speed boost when eating a fly and the bees.", SCREEN_WIDTH // 16, (SCREEN_HEIGHT // 2 - 30),
                            arcade.color.WHITE, 13)
           arcade.draw_text("Press the space bar to continue.", SCREEN_WIDTH // 16, (SCREEN_HEIGHT // 2 - 60),
                            arcade.color.WHITE, 13)

        # Set up draw game when started
       elif self.current_state == GAME_RUNNING:
           self.draw_game()

        # Set up game over screen with text
       elif self.current_state == GAME_OVER:
           arcade.draw_text("Game Over!", SCREEN_WIDTH // 7, (SCREEN_HEIGHT // 2 - 20), arcade.color.WHITE, 20)


    def draw_game(self):

       self.fly.draw()
       self.bee.draw()
       self.player_list.draw()
       self.scene.draw()
       # Put the score on the screen.
       output = f"Score: {self.score}"
       arcade.draw_text(output, 10, 20, arcade.color.WHITE, 14)


    def on_key_press(self, key, modifiers):
      # Movement controls for frog sprite
       if key == arcade.key.UP:
           self.player_sprite.change_y = MOVEMENT_SPEED
       elif key == arcade.key.DOWN:
           self.player_sprite.change_y = -MOVEMENT_SPEED
       elif key == arcade.key.LEFT:
           self.player_sprite.change_x = -MOVEMENT_SPEED
       elif key == arcade.key.RIGHT:
           self.player_sprite.change_x = MOVEMENT_SPEED


    def on_key_release(self, key, modifiers):
       # How far the frog moves when key is pressed
        if key == arcade.key.UP or key == arcade.key.DOWN or key == arcade.key.W:
            self.player_sprite.change_y = 0
        elif key == arcade.key.LEFT or key == arcade.key.RIGHT:
            self.player_sprite.change_x = 0


           # Change the screen to running
        if key == arcade.key.SPACE:
            if self.current_state == GAME_INTRO:
                self.current_state= GAME_RUNNING
        elif key == arcade.key.ESCAPE:
            if self.current_state == GAME_OVER:
                self.close()


    def on_update(self, delta_time):
       # List updates
        self.player_list.update()
        self.bee.update()
        self.fly.update()


       # Generate a list of all sprites that collided with the frog and flies (scenes)
        flies_hit_list = arcade.check_for_collision_with_list(self.player_sprite,
                                                             self.scene["Flies"])

       # If a fly is in the hit list, it will be removed and respawned
        for fly in flies_hit_list:

           # Removes the fly when interacted with frog
            fly.remove_from_sprite_lists()
            arcade.play_sound(self.eatnoise)
           # Add point
            self.score += 1
           # Replays the code so it reappears
            for i in range(1):
                fly = arcade.Sprite(":resources:images/enemies/fly.png", SPRITE_SCALING_FLY)
                fly.center_x = random.randrange(SCREEN_WIDTH)
                fly.center_y = random.randrange(SCREEN_HEIGHT)
                self.scene.add_sprite("Flies", fly)
                # A brief speed boost is gained when the frog eats a fly
                self.player_sprite.change_y *= 3
                self.player_sprite.change_x *= 3

            # Sets up the bee sprite so that each time a fly is eaten, another new bee appears
            for i in range(1):
                bee = arcade.Sprite(":resources:images/enemies/bee.png", SPRITE_SCALING_BEE)
                bee.center_x = random.randrange(SCREEN_WIDTH)
                bee.center_y = random.randrange(SCREEN_HEIGHT)
                self.scene.add_sprite("Bees", bee)


        # Game ends when bee and frog collide
        bees_hit_list = arcade.check_for_collision_with_list(self.player_sprite,
                                                         self.scene["Bees"])
        for bee in bees_hit_list:
            arcade.play_sound(self.endnoise)
            self.current_state = GAME_OVER



def main():
   # Main method
   window = MyGame()
   window.setup()
   arcade.run()


if __name__ == "__main__":
   main()









